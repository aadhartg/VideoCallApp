﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;

namespace VideoCallConsultant.Services
{
    public static class Zoom
    {
        public static IRestResponse getAccessToken()
        {
            var client = new RestClient("https://zoom.us/oauth/token");
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/x-www-form-urlencoded");
            string url = "https://localhost:44391/";
            string code = "8NpGLQXYyV_2JpsTVi6Sdah6VlaIdHqLg";
            request.AddParameter("application/x-www-form-urlencoded", "grant_type=authorization_code&code=" + code + "&redirect_uri=" + url, ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            return response;
        }
        public static IRestResponse getZoomUsers(string token)
        {
            var client = new RestClient("https://api.zoom.us/v2/users");
            var request = new RestRequest(Method.GET);
            request.AddHeader("Token", "Bearer " + token);
            IRestResponse response = client.Execute(request);
            return response;
        }

        public static async Task<Token> TesttokenAsync()
        {
            HttpClient client = new HttpClient();
            string baseAddress = @"https://zoom.us/oauth/token";

            string grant_type = "authorization_code";
            string redirect_uri = "8GlY4LsDvB_2JpsTVi6Sdah6VlaIdHqLg";
            string code = "8NpGLQXYyV_2JpsTVi6Sdah6VlaIdHqLg";

            var form = new Dictionary<string, string>
                {
                    {"grant_type", grant_type},
                    {"code", code},
                    {"redirect_uri", redirect_uri},
                };

            HttpResponseMessage tokenResponse = await client.PostAsync(baseAddress, new FormUrlEncodedContent(form));
            var jsonContent = await tokenResponse.Content.ReadAsStringAsync();
            Token tok = JsonConvert.DeserializeObject<Token>(jsonContent);
            return tok;
        }


        public class Token
        {
            [JsonProperty("access_token")]
            public string AccessToken { get; set; }

            [JsonProperty("token_type")]
            public string TokenType { get; set; }

            [JsonProperty("expires_in")]
            public int ExpiresIn { get; set; }

            [JsonProperty("refresh_token")]
            public string RefreshToken { get; set; }
        }
    }
}