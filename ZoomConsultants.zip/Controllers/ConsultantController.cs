﻿using Glimpse.Core.ClientScript;
using Microsoft.AspNet.Identity;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using VideoCallConsultant.EntityModels;
using VideoCallConsultant.ViewModels;

namespace VideoCallConsultant.Controllers
{
    [Authorize]
    public class ConsultantController : BaseController
    {
        ApplicationIdentity Identity;
        // GET: Consultant
        public ActionResult Index()
        {
                return View();
        }

        public ActionResult Booking()
        {

            DateTime week = DateTime.Now.Date.AddDays(7);
            var todaydate = DateTime.UtcNow.Date;
            BookingViewModel bookingViewModels = new BookingViewModel();
            List<Booking> bookingList = new List<Booking>();
            using (var db = GetDb())
            {
                bookingList = db.Booking.ToList();
            }
            bookingViewModels.ThreeHourWebiner = bookingList.Where(z => z.UTCStartTime.Date >= todaydate && z.UTCStartTime.Date <= week && z.SessionType == 1).ToList();
            bookingViewModels.OneHourWebiner = bookingList.Where(z => z.UTCStartTime.Date >= todaydate && z.UTCStartTime.Date <= week && z.SessionType == 2).ToList();
            bookingViewModels.TenMinuteWebiner = bookingList.Where(z => z.UTCStartTime.Date >= todaydate && z.UTCStartTime.Date <= week && z.SessionType == 3).ToList();
            return View(bookingViewModels);
        }

        public bool AddBooking3Hour(string datetime)
        {
            //Task<Token> tok = Task.Run<Token>(async () => await TesttokenAsync());

            //IRestResponse resp = getAccessToken();
            //if (resp.StatusCode == HttpStatusCode.OK)
            //{
            //    var data = getZoomUsers(resp.Content);
            //}

            char[] delimiters = new char[] { '\n' };
            string[] datestr = datetime.Split(delimiters);
            DateTime bookingDate = Convert.ToDateTime(datestr[2] + " " + datestr[3]);
            bool result = false;
            Booking model = new Booking();
            model.UserId = User.Identity.GetUserId();
            model.SessionAttended = false;
            model.SessionExpired = false;
            model.SessionType = 1;
            model.URL = 1;
            model.UTCStartTime = bookingDate;
            model.UTCEndTime = bookingDate.AddHours(3);
            using (var db = GetDb())
            {
               db.Booking.Add(model);
               int recordsinserted = db.SaveChanges();
                if (recordsinserted > 0)
                    result = true;
            }
            return result;
        }

        public bool AddBooking1Hour(string datetime)
        {
            char[] delimiters = new char[] { '\n' };
            string[] datestr = datetime.Split(delimiters);
            DateTime bookingDate = Convert.ToDateTime(datestr[2] + " " + datestr[3]);
            bool result = false;
            Booking model = new Booking();
            model.UserId = User.Identity.GetUserId();
            model.SessionAttended = false;
            model.SessionExpired = false;
            model.SessionType = 2;
            model.URL = 1;
            model.UTCStartTime = bookingDate;
            model.UTCEndTime = bookingDate.AddHours(3);
            using (var db = GetDb())
            {
                db.Booking.Add(model);
                int recordsinserted = db.SaveChanges();
                if (recordsinserted > 0)
                    result = true;
            }
            return result;
        }

        public ActionResult Sessions()
        {
            return View();
        }

        public ActionResult UserBookings()
        {

            return View();
        }
    }
}