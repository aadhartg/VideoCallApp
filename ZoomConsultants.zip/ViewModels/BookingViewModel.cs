﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VideoCallConsultant.EntityModels;

namespace VideoCallConsultant.ViewModels
{
    public class BookingViewModel
    {
        public List<Booking> OneHourWebiner { get; set; }
        public List<Booking> ThreeHourWebiner { get; set; }
        public List<Booking> TenMinuteWebiner { get; set; }
    }
}